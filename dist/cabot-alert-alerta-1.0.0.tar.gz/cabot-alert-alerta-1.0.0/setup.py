#!/usr/bin/env python

from setuptools import setup

setup(name='cabot-alert-alerta',
      version='1.0.0',
      description='',
      author='Suntek.Q.Ma',
      author_email='165318903@qq.com',
      url='https://github.com/Suntekma',
      packages=[
      	'cabot_alert_alerta'
      	],
      download_url= 'https://github.com/suntekma'
     )